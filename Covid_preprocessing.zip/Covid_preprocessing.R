root <- dirname(rstudioapi::getActiveDocumentContext()$path)
setwd(root)

rm(list=ls())

if (!require("pacman")) install.packages("pacman")
pacman::p_load("data.table", "readxl", "janitor", "lubridate", "scales", "purrr", "tidyverse", "splitstackshape")

options(scipen=999) # turn-off scientific notation like 1e+48
options(tibble.width = Inf)


# Data load ---------------------------------------------------------------
roaming_data1 <- fread("2. Roaming_data1.csv", encoding = "UTF-8")
roaming_data2 <- fread("2. Roaming_data2.csv", encoding = "UTF-8")
roaming_data3 <- fread("2. Roaming_data3.csv", encoding = "UTF-8")

roaming_data <- rbind(roaming_data1, roaming_data2, roaming_data3)
rm(roaming_data1, roaming_data2, roaming_data3)

covid_global <- fread("WHO-COVID-19-global-data.csv", encoding = "UTF-8")
population <- fread("Population_for_challenge.csv", encoding = "UTF-8")
population$V3 <- NULL

y <- fread("y_value.csv")
y <- y %>% mutate(date = ymd(date))

# Roaming data preprocessing ----------------------------------------------
roaming_data_new <-  roaming_data %>% 
  mutate(stay_time = ymd(departure)-ymd(arrival),
         flight_time = ymd(return)-ymd(departure))

roaming_data_useful <- roaming_data_new %>% 
  mutate(return = ymd(return),
         arrival = ymd(arrival),
         departure = ymd(departure)) %>% 
  arrange(return) %>% 
  filter(return >= "2020-01-26")


roaming_data_useful_14 <- roaming_data_useful %>% filter(flight_time <= 14)
rm(roaming_data, roaming_data_new, roaming_data_useful)


# Exclude ISO code --------------------------------------------------------
population %>%
  left_join(covid_global %>%
              mutate(Country = str_to_lower(Country)) %>%
              filter(day >= "2020-01-10"), by=c("iso" = "Country")) %>%
  select(-`Country Name`, -Region) %>%
  select(day, iso, Confirmed, Cumulative_confirmed = `Cumulative Confirmed`, population) %>%
  mutate(adj_confirmed = Confirmed/population) %>%
  group_by(iso) %>%
  mutate(grad_confirmed = Confirmed - lag(Confirmed)) %>%
  ungroup() %>% filter(is.na(day)) %>% select(iso) %>% unique() %>% unlist() -> day_na


# Daily count -------------------------------------------------------------
'%!in%' <- function(x,y)!('%in%'(x,y))

day_unique <- roaming_data_useful_14$return %>% as.character() %>% unique()
a <- list()
cnt <- 0

for (k in day_unique) {
  cnt <- cnt + 1
  a[[cnt]] <- roaming_data_useful_14 %>%
    select(-arrival, -departure) %>% 
    filter(iso %!in% day_na) %>%
    filter(return == k) %>%
    mutate(total_time = flight_time + stay_time) %>% 
    rowwise() %>% 
    mutate(day = ifelse(total_time >= 14, paste0(seq(flight_time, 14, 1), collapse = ","), paste0(seq(flight_time, total_time, 1), collapse = ","))) %>% 
    cSplit_e("day", ",", type = "character", fill = 0) %>% 
    select(-contains("time"), -day) %>% 
    gather(key = D_day, value = n, 4:18) %>%
    mutate(total_n = count * n) %>% select(-count, -n) %>%
    group_by(return, iso, D_day) %>% 
    summarise(total_n = sum(total_n)) %>% 
    spread(key = iso, value = total_n) %>% 
    slice(1:2, 8:15, 3:7) %>% 
    ungroup() %>% 
    mutate(return = return - 0:14) %>% 
    rename(Date = return)
}


# Daily risk --------------------------------------------------------------
b <- list()
cnt <- 0
for (j in 1:length(a)) {
  
  cnt <- cnt+1
  
  b[[j]] <- population %>% 
    left_join(covid_global %>%
                mutate(Country = str_to_lower(Country)) %>% 
                filter(day >= "2020-01-11"), by=c("iso" = "Country")) %>% 
    filter(Confirmed >= 0) %>%
    select(-`Country Name`, -Region) %>% 
    select(day, iso, Confirmed, Cumulative_confirmed = `Cumulative Confirmed`, population) %>% 
    mutate(population = (population-min(population, na.rm = T))/(max(population, na.rm = T)-min(population, na.rm = T))) %>%
    mutate(adj_confirmed = ((Confirmed + 1)/(population + 1))) %>% 
    group_by(iso) %>%
    mutate(trend_confirmed = Confirmed - lag(Confirmed)) %>%
    mutate(trend_confirmed = (trend_confirmed-min(trend_confirmed, na.rm = T))/(max(trend_confirmed, na.rm = T)-min(trend_confirmed, na.rm = T))) %>%
    mutate(trend_confirmed = trend_confirmed + 1) %>%
    ungroup() %>% 
    filter(day >= "2020-01-12") %>% 
    mutate(risk_trend = adj_confirmed * trend_confirmed) %>% 
    # mutate(risk_trend = risk_trend + 1) %>%
    select(Date = day, iso, risk_trend) %>% 
    spread(key = iso, value = risk_trend, fill = 0) %>% 
    select(one_of(a[[j]] %>% select(-2) %>% colnames())) %>% 
    filter(Date %in% c(a[[j]] %>% mutate(Date = as.character(Date)) %>% select(Date) %>% unlist()))
}

c <- data.frame()
for (s in 1:length(a)) {
  
  combine_risk <- (a[[s]] %>% select(-1,-2)) * (b[[s]] %>% arrange(-row_number()) %>% select(-1))
  
  temp <- a[[s]] %>% select(1,2) %>% 
    cbind(combine_risk %>%
            mutate(Risk_sum = select_all(.) %>% rowSums(na.rm = T))) %>% 
    select(D_day, Risk_sum) %>% 
    spread(D_day, Risk_sum) %>% 
    mutate(Return = a[[s]] %>% select(Date) %>% mutate(Date = as.character(Date)) %>% slice(1) %>% unlist() %>% ymd()) %>% 
    select(16, 1:2, 8:15, 3:7)
  
  c <- rbind(c, temp)
}

final_dataset <- c %>% mutate(Return = ymd(Return)) %>% left_join(y, by=c("Return" = "date")) %>% select(-2)

rm(list=setdiff(ls(), "final_dataset"))

# 최종 전처리 파일 csv로 출력
fwrite(final_dataset, "Preprocessed_COVIDdataset.csv")
